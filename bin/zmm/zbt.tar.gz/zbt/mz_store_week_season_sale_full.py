#!/usr/bin/env python
# coding:utf-8

# **********************************************************
# * Author        : xfzheng
# * Email         : 329472010@qq.com
# * Create time   : 2019-03-29 11:30
# * Last modified : 2019-03-29 11:30
# * Filename      : class_template.py
# * Description   :
# **********************************************************
from BaseDag import BaseDag


class Mzstoreweekseasonsalefull(BaseDag):
    '''

    auto create class and fill sqll

    '''

    def __init__(self):
        BaseDag.__init__(self)

    def run_command(self):
        self.sql = """drop  table belle_sh.mz_store_week_season_sale_full;
create table belle_sh.mz_store_week_season_sale_full as
select
store_no,
weekYearSale,
seasonYearSKU,
cnt_qty_season_store,
futr2_season_store,
tr4_season_store,
rto_l4w_yoy,
mean2_season_store,
mean4_season_store,
futr2_season_store_LY1,
((futr2_season_store_LY1*rto_l4w_yoy + 2*mean4_season_store + 2*mean2_season_store)/3) as futr2_season_store_pred_meg,
((((futr2_season_store_LY1*rto_l4w_yoy + 2*mean4_season_store + 2*mean2_season_store)/3)-futr2_season_store)/futr2_season_store) as err_futr2_season_store_pred_meg
from(
    select 
    store_no,
    weekYearSale,
    seasonYearSKU,
    cnt_qty_season_store,
    mean2_season_store,
    mean4_season_store,
    mean4_season_store_LY1,
    futr2_season_store,
    futr2_season_store_LY1,
    tr4_season_store,
    itcpt_season_store,
    (mean4_season_store/mean4_season_store_LY1) as rto_l4w_yoy
    
    from(
        select 
        A.store_no,
        A.weekYearSale,
        A.seasonYearSKU,
        A.cnt_qty_season_store,
        A.mean4_season_store,
        A.mean2_season_store,
        A.futr2_season_store,
        A.tr4_season_store,
        A.itcpt_season_store,
        B.mean4_season_store as mean4_season_store_LY1,
        B.mean2_season_store as mean2_season_store_LY1,
        B.futr2_season_store as futr2_season_store_LY1,
        B.tr4_season_store as tr4_season_store_LY1,
        B.itcpt_season_store as itcpt_season_store_LY1
        from
            belle_sh.mz_store_week_season_sale A
        left join
            belle_sh.mz_store_week_season_sale B
        on A.store_no = B.store_no and A.week = B.week and A.sale_year = B.sale_year + 1 and A.product_season_name = B.product_season_name and cast(A.product_year_name as int) = cast(B.product_year_name as int) + 1
        ) store_1
    ) store_2
    where store_2.mean4_season_store_LY1 is not null

  


"""
        self.call()

if __name__ == '__main__':
    Mzstoreweekseasonsalefull().run_command()
