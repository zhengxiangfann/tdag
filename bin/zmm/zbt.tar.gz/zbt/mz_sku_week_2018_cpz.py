#!/usr/bin/env python
# coding:utf-8

# **********************************************************
# * Author        : xfzheng
# * Email         : 329472010@qq.com
# * Create time   : 2019-03-29 11:30
# * Last modified : 2019-03-29 11:30
# * Filename      : class_template.py
# * Description   :
# **********************************************************
from BaseDag import BaseDag


class Mzskuweek2018cpz(BaseDag):
    '''

    auto create class and fill sqll

    '''

    def __init__(self):
        BaseDag.__init__(self)

    def run_command(self):
        self.sql = """drop  table belle_sh.mz_sku_week_2018_cpz;
create table belle_sh.mz_sku_week_2018_cpz as
select d.*,
       case when (num_rank_season)/(cnt_sku_week_season) <= 0.2 then '畅销款'
            when (num_rank_season)/(cnt_sku_week_season) <= 0.8 then '平销款'
            else '滞销款' end as ind_cpz_season
from
 (select c.*,
        row_number() over(partition by weekYearSale,seasonYearSKU order by last_2_week_qty desc) as num_rank_season,
        count(distinct product_code) over(partition by weekYearSale,seasonYearSKU) as cnt_sku_week_season
 from   
    (select product_code,weekYearSale,product_year_name,seasonYearSKU,
           qty+nvl(qty_L1,0) as last_2_week_qty
    from
		(select a.*,
		       lag(qty,1) over(partition by product_code order by weekYearSale) as qty_L1
		from
			( 
			select product_code,weekYearSale,product_year_name,seasonYearSKU,
			sum(qty) as qty
			from belle_sh.mz_sku_store_size_week
			group by product_code, weekYearSale, product_year_name, seasonYearSKU
			) a
		) b
	) c
 ) d




"""
        self.call()

if __name__ == '__main__':
    Mzskuweek2018cpz().run_command()
