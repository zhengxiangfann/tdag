#!/usr/bin/env python
# coding:utf-8

# **********************************************************
# * Author        : xfzheng
# * Email         : 329472010@qq.com
# * Create time   : 2019-03-29 11:30
# * Last modified : 2019-03-29 11:30
# * Filename      : class_template.py
# * Description   :
# **********************************************************
from BaseDag import BaseDag


class Mzweekseasonareasalefull(BaseDag):
    '''

    auto create class and fill sqll

    '''

    def __init__(self):
        BaseDag.__init__(self)

    def run_command(self):
        self.sql = """drop  table belle_sh.mz_week_season_area_sale_full;
create table belle_sh.mz_week_season_area_sale_full as
select
weekYearSale,
seasonYearSKU,
cnt_qty_season_area,
futr2_season_area,
tr4_season_area,
rto_l4w_yoy,
mean2_season_area,
mean4_season_area,
futr2_season_area_LY1,
((futr2_season_area_LY1*rto_l4w_yoy + 2*mean4_season_area + 2*mean2_season_area)/3) as futr2_season_area_pred_meg,
((((futr2_season_area_LY1*rto_l4w_yoy + 2*mean4_season_area + 2*mean2_season_area)/3)-futr2_season_area)/futr2_season_area) as err_futr2_season_area_pred_meg
from(
    select 
    weekYearSale,
    seasonYearSKU,
    cnt_qty_season_area,
    mean2_season_area,
    mean4_season_area,
    mean4_season_area_LY1,
    futr2_season_area,
    futr2_season_area_LY1,
    tr4_season_area,
    itcpt_season_area,
    (mean4_season_area/mean4_season_area_LY1) as rto_l4w_yoy
    
    from(
        select 
        A.weekYearSale,
        A.seasonYearSKU,
        A.cnt_qty_season_area,
        A.mean4_season_area,
        A.mean2_season_area,
        A.futr2_season_area,
        A.tr4_season_area,
        A.itcpt_season_area,
        B.mean4_season_area as mean4_season_area_LY1,
        B.futr2_season_area as futr2_season_area_LY1
        from
            belle_sh.mz_week_season_area_sale A
        left join
            belle_sh.mz_week_season_area_sale B
        on A.week = B.week and A.sale_year = B.sale_year + 1 and A.product_season_name = B.product_season_name and cast(A.product_year_name as int) = cast(B.product_year_name as int) + 1
        ) season_area_1
    ) season_area_2
    where season_area_2.mean4_season_area_LY1 is not null

    


"""
        self.call()

if __name__ == '__main__':
    Mzweekseasonareasalefull().run_command()
