#!/usr/bin/env python
# coding:utf-8

# **********************************************************
# * Author        : xfzheng
# * Email         : 329472010@qq.com
# * Create time   : 2019-03-29 11:30
# * Last modified : 2019-03-29 11:30
# * Filename      : class_template.py
# * Description   :
# **********************************************************
from BaseDag import BaseDag


class Mzcatsizedist(BaseDag):
    '''

    auto create class and fill sqll

    '''

    def __init__(self):
        BaseDag.__init__(self)

    def run_command(self):
        self.sql = """drop  table  belle_sh.mz_cat_size_dist;
create table belle_sh.mz_cat_size_dist as 
select
    c.*
    ,sum_qty_220/sum_qty as pct_qty_220
    ,sum_qty_225/sum_qty as pct_qty_225
    ,sum_qty_230/sum_qty as pct_qty_230
    ,sum_qty_235/sum_qty as pct_qty_235
    ,sum_qty_240/sum_qty as pct_qty_240
    ,sum_qty_245/sum_qty as pct_qty_245

    ,cumu_qty_220/cumu_qty as pct_cumu_qty_220
    ,cumu_qty_225/cumu_qty as pct_cumu_qty_225
    ,cumu_qty_230/cumu_qty as pct_cumu_qty_230
    ,cumu_qty_235/cumu_qty as pct_cumu_qty_235
    ,cumu_qty_240/cumu_qty as pct_cumu_qty_240
    ,cumu_qty_245/cumu_qty as pct_cumu_qty_245

    ,sum_qty_220_lastyear/sum_qty_lastyear as pct_qty_220_lastyear
    ,sum_qty_225_lastyear/sum_qty_lastyear as pct_qty_225_lastyear
    ,sum_qty_230_lastyear/sum_qty_lastyear as pct_qty_230_lastyear
    ,sum_qty_235_lastyear/sum_qty_lastyear as pct_qty_235_lastyear
    ,sum_qty_240_lastyear/sum_qty_lastyear as pct_qty_240_lastyear
    ,sum_qty_245_lastyear/sum_qty_lastyear as pct_qty_245_lastyear
    ,if(sum_qty_lastyear is null, 1,least(1, cumu_qty/sum_qty_lastyear/2) ) as factor
from 
(
    select
    a.*
    ,sum(sum_qty_220) over(partition by a.product_year_name,a.product_season_name,a.category_name3,a.heel_type_name order by a.weekYearSale ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) as cumu_qty_220
    ,sum(sum_qty_225) over(partition by a.product_year_name,a.product_season_name,a.category_name3,a.heel_type_name order by a.weekYearSale ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) as cumu_qty_225
    ,sum(sum_qty_230) over(partition by a.product_year_name,a.product_season_name,a.category_name3,a.heel_type_name order by a.weekYearSale ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) as cumu_qty_230
    ,sum(sum_qty_235) over(partition by a.product_year_name,a.product_season_name,a.category_name3,a.heel_type_name order by a.weekYearSale ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) as cumu_qty_235
    ,sum(sum_qty_240) over(partition by a.product_year_name,a.product_season_name,a.category_name3,a.heel_type_name order by a.weekYearSale ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) as cumu_qty_240
    ,sum(sum_qty_245) over(partition by a.product_year_name,a.product_season_name,a.category_name3,a.heel_type_name order by a.weekYearSale ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) as cumu_qty_245
    ,sum(sum_qty) over(partition by a.product_year_name,a.product_season_name,a.category_name3,a.heel_type_name order by a.weekYearSale ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) as cumu_qty
    ,sum_qty_220_lastyear
    ,sum_qty_225_lastyear
    ,sum_qty_230_lastyear
    ,sum_qty_235_lastyear
    ,sum_qty_240_lastyear
    ,sum_qty_245_lastyear
    ,sum_qty_lastyear

from belle_sh.mz_cat_size_stat a 
left join 
(   
    select
    product_year_name
    ,cast(cast(product_year_name as int)+1 as string) as product_year_match
    ,product_season_name
    ,category_name3
    ,heel_type_name
    ,sum(sum_qty_220) as sum_qty_220_lastyear
    ,sum(sum_qty_225) as sum_qty_225_lastyear
    ,sum(sum_qty_230) as sum_qty_230_lastyear
    ,sum(sum_qty_235) as sum_qty_235_lastyear
    ,sum(sum_qty_240) as sum_qty_240_lastyear
    ,sum(sum_qty_245) as sum_qty_245_lastyear
    ,sum(sum_qty)     as sum_qty_lastyear
    from belle_sh.mz_cat_size_stat 
    group by 
    product_year_name
    ,cast(cast(product_year_name as int)+1 as string)
    ,product_season_name
    ,category_name3
    ,heel_type_name
) b 
on a.product_year_name=b.product_year_match and a.product_season_name=b.product_season_name and a.category_name3=b.category_name3 and a.heel_type_name=b.heel_type_name
) c 




"""
        self.call()

if __name__ == '__main__':
    Mzcatsizedist().run_command()
