#!/usr/bin/env python
# coding:utf-8

# **********************************************************
# * Author        : xfzheng
# * Email         : 329472010@qq.com
# * Create time   : 2019-03-29 11:30
# * Last modified : 2019-03-29 11:30
# * Filename      : class_template.py
# * Description   :
# **********************************************************
from BaseDag import BaseDag


class Mzskustoresizeweek(BaseDag):
    '''

    auto create class and fill sqll

    '''

    def __init__(self):
        BaseDag.__init__(self)

    def run_command(self):
        self.sql = """drop  table belle_sh.mz_sku_store_size_week;
create table belle_sh.mz_sku_store_size_week as
select grpweek.*, B.in_inv,
concat_ws('-',CAST(grpweek.sale_year AS VARCHAR(20)),substring(concat('00',CAST(grpweek.week AS VARCHAR(20))),-2)) as weekYearSale,
concat_ws('-',grpweek.product_season_name,grpweek.product_year_name) as seasonYearSKU
from
(
    select store_no,product_code,size_no,week,sale_year,product_season_name,product_year_name,product_dsn,
    max(inv_date) as date_inv_end,
    sum(nvl(qty,0)) as qty,
    sum(nvl(amount,0)) as sum_amt,
    sum(nvl(tag_amount,0)) as sum_tag_amt,
    sum(nvl(amount,0))/sum(nvl(tag_amount,0)) as rto_discount,
    count(distinct(inv_date)) as sale_days,
    sum(nvl(qty,0))/count(distinct(inv_date)) as rto_sell
    from
    (
    select addweek.*,
    case when sale_month=12 and week=1 then (year(to_date(from_unixtime(unix_timestamp(inv_date,'yyyyMMdd'))))+1)
    else (year(to_date(from_unixtime(unix_timestamp(inv_date,'yyyyMMdd'))))) end as sale_year
    from
        (
            select 
            *,
            weekofyear(to_date(from_unixtime(unix_timestamp(inv_date,'yyyyMMdd')))) as week,
            month(to_date(from_unixtime(unix_timestamp(inv_date,'yyyyMMdd')))) as sale_month,
            substring(product_code,1,6) as product_dsn
            from belle_sh.mz_sale_inv_st_2017_2019
            where brand_no = 'ST' and region_name = '华东'
        ) addweek
    ) corweek
    group by store_no,product_code,size_no,week,sale_year,product_season_name,product_year_name,product_dsn
) grpweek
left join
    belle_sh.mz_sale_inv_st_2017_2019 B
on grpweek.store_no = B.store_no and grpweek.product_code = B.product_code and grpweek.size_no = B.size_no and grpweek.date_inv_end = B.inv_date




"""
        self.call()

if __name__ == '__main__':
    Mzskustoresizeweek().run_command()
