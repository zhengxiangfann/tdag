#!/usr/bin/env python
# coding:utf-8

# **********************************************************
# * Author        : xfzheng
# * Email         : 329472010@qq.com
# * Create time   : 2019-03-29 11:30
# * Last modified : 2019-03-29 11:30
# * Filename      : class_template.py
# * Description   :
# **********************************************************
from BaseDag import BaseDag


class Mzstoreweekseasonsale(BaseDag):
    '''

    auto create class and fill sqll

    '''

    def __init__(self):
        BaseDag.__init__(self)

    def run_command(self):
        self.sql = """drop  table belle_sh.mz_store_week_season_sale;
create table belle_sh.mz_store_week_season_sale as
select *,
(mean4_season_store - tr4_season_store*(-1.5)) as itcpt_season_store
from(
    select *,
    (1.5*(cnt_qty_season_store - mean4_season_store)+0.5*(cnt_qty_season_store_L1 - mean4_season_store)-0.5*(cnt_qty_season_store_L2 - mean4_season_store)-1.5*(cnt_qty_season_store_L3 - mean4_season_store)) as tr4_season_store
    from(
        select *,
        (cnt_qty_season_store + cnt_qty_season_store_L1 + cnt_qty_season_store_L2 + cnt_qty_season_store_L3)/4 as mean4_season_store,
        (cnt_qty_season_store + cnt_qty_season_store_L1 )/2 as mean2_season_store,
        (cnt_qty_season_store_F1 + cnt_qty_season_store_F2) as futr2_season_store
        from(
            select *,
            LAG(cnt_qty_season_store, 1,NULL) OVER (PARTITION BY store_no,seasonYearSKU ORDER BY weekYearSale ASC) AS cnt_qty_season_store_L1,
            LAG(cnt_qty_season_store, 2,NULL) OVER (PARTITION BY store_no,seasonYearSKU ORDER BY weekYearSale ASC) AS cnt_qty_season_store_L2,
            LAG(cnt_qty_season_store, 3,NULL) OVER (PARTITION BY store_no,seasonYearSKU ORDER BY weekYearSale ASC) AS cnt_qty_season_store_L3,
            lead(cnt_qty_season_store, 1,NULL) OVER (PARTITION BY store_no,seasonYearSKU ORDER BY weekYearSale ASC) AS cnt_qty_season_store_F1,
            lead(cnt_qty_season_store, 2,NULL) OVER (PARTITION BY store_no,seasonYearSKU ORDER BY weekYearSale ASC) AS cnt_qty_season_store_F2
            from(
                select store_no, weekYearSale, week, sale_year, seasonYearSKU, product_season_name, product_year_name,
                sum(qty) as cnt_qty_season_store,
                sum(sum_amt) as sum_amt
                from belle_sh.mz_sku_store_size_week
                group by store_no, weekYearSale, week, sale_year, seasonYearSKU, product_season_name, product_year_name
                ) store_1
            ) store_2
        ) store_3
    ) store_4


"""
        self.call()

if __name__ == '__main__':
    Mzstoreweekseasonsale().run_command()
