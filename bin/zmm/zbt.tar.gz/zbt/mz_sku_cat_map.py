#!/usr/bin/env python
# coding:utf-8

# **********************************************************
# * Author        : xfzheng
# * Email         : 329472010@qq.com
# * Create time   : 2019-03-29 11:30
# * Last modified : 2019-03-29 11:30
# * Filename      : class_template.py
# * Description   :
# **********************************************************
from BaseDag import BaseDag


class Mzskucatmap(BaseDag):
    '''

    auto create class and fill sqll

    '''

    def __init__(self):
        BaseDag.__init__(self)

    def run_command(self):
        self.sql = """drop  table  belle_sh.mz_sku_cat_map;
create table belle_sh.mz_sku_cat_map as 
select product_code,product_year_name,product_season_name, seasonYearSKU, heel_type_name, category_name3
from (
    select product_code,product_year_name,product_season_name,
    concat_ws('-',product_season_name,product_year_name) as seasonYearSKU,
    case when heel_type_name in ('低','平') then '低'
         when heel_type_name = '中' then '中'
         when heel_type_name = '高' then '高'
         else '不涉及'
         end as heel_type_name,
    IF(category_name3 like '%靴%','靴',IF(category_name3 like '%空%','空',category_name3)) as category_name3
    from data_belle.dim_pro_allinfo
    where category_flag!=0 and category_name1='鞋' and brand_no='ST'
    ) A
    group by product_code,product_year_name,product_season_name, seasonYearSKU, heel_type_name, category_name3

"""
        self.call()

if __name__ == '__main__':
    Mzskucatmap().run_command()
